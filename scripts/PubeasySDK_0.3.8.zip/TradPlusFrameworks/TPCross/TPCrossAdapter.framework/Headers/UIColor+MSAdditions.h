#import <UIKit/UIKit.h>

@interface UIColor (MSAdditions)

+ (UIColor *)mp_colorFromHexString:(NSString *)hexString alpha:(CGFloat)alpha;

@end
