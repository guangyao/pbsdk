#import "TPFullscreenAdViewController.h"

@class TPImageCreativeView;

NS_ASSUME_NONNULL_BEGIN

@interface TPFullscreenAdViewController (Image)

- (void)prepareImageAdWithImageCreativeView:(UIImageView *)imageCreativeView;

@end

NS_ASSUME_NONNULL_END
