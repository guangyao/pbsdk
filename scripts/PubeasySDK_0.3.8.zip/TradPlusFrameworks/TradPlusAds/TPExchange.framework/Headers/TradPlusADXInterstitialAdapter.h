//
//  TradPlusADXInterstitialAdapter.h
//  fluteSDKSample
//
//  Created by xuejun on 2021/10/15.
//  Copyright © 2021 TradPlus. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <TradPlusAds/TradPlusBaseAdapter.h>

NS_ASSUME_NONNULL_BEGIN

@interface TradPlusADXInterstitialAdapter : TradPlusBaseAdapter

@end

NS_ASSUME_NONNULL_END
