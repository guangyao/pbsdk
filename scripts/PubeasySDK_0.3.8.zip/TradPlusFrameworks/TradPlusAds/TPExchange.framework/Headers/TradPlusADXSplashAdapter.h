//
//  TradPlusADXSplashAdapter.h
//  TradPlusAds
//
//  Created by xuejun on 2023/2/9.
//  Copyright © 2023 TradPlus. All rights reserved.
//

#import <TradPlusAds/TradPlusAds.h>
#import <TradPlusAds/TradPlusBaseAdapter.h>

NS_ASSUME_NONNULL_BEGIN

@interface TradPlusADXSplashAdapter : TradPlusBaseAdapter

@end

NS_ASSUME_NONNULL_END
