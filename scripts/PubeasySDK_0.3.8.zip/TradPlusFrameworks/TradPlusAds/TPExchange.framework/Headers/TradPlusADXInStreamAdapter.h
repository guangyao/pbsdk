//
//  TradPlusADXInStreamAdapter.h
//  TradPlusAds
//
//  Created by xuejun on 2023/8/16.
//  Copyright © 2023 TradPlus. All rights reserved.
//

#import <TradPlusAds/TradPlusAds.h>
#import <TradPlusAds/TradPlusBaseAdapter.h>

NS_ASSUME_NONNULL_BEGIN

@interface TradPlusADXInStreamAdapter : TradPlusBaseAdapter

@end

NS_ASSUME_NONNULL_END
