//
//  TPFullEventControl.h
//  TradPlusAds
//
//  Created by xuejun on 2022/7/1.
//  Copyright © 2022 TradPlus. All rights reserved.
//

#import <TradPlusAds/TPEventControl.h>

NS_ASSUME_NONNULL_BEGIN

@interface TPFullEventControl : TPEventControl

@end

NS_ASSUME_NONNULL_END
