//
//  TPNativeInterstitialHalfTemplate.h
//  TradPlusAds
//
//  Created by xuejun on 2024/2/26.
//  Copyright © 2024 TradPlus. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TPNativeInterstitialHalfTemplate : UIView

@property (nonatomic,weak)IBOutlet NSLayoutConstraint *iconImageWidth;
@property (nonatomic,weak)IBOutlet NSLayoutConstraint *titleLabelLeft;
@property (nonatomic,weak)IBOutlet NSLayoutConstraint *textLabelLeft;
@end

NS_ASSUME_NONNULL_END
