//
//  MsLogViewController.h
//  TradPlusAds
//
//  Created by hy on 2020/4/21.
//  Copyright © 2020 TradPlusAd All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MsLogViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextView *textView;

@end

NS_ASSUME_NONNULL_END
