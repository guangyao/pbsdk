//
//  MSConstants.h
//
//  Copyright 2016 TradPlusAd, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

//测试版本号使用4位
//#define MS_SDK_VERSION              @"14.1.0.0"
//买量时使用5位版本号
//#define MS_SDK_VERSION              @"14.1.0.0.0"
//正式版使用3位
#define MS_SDK_VERSION              @"14.1.0"
